//
//  main.cpp
//  Banker's Algorithm
//
//  Created by Noel Esqueda on 3/17/19.
//  Copyright © 2019 Noel Esqueda. All rights reserved.
//

#include <iostream>
using namespace std;

// Global constants

// Number of processes
const int p = 5;

// Number of resources
const int r = 3;

struct state
{
    int avail[r];           // available resources of each type
    int max[p][r];          // maximum demand of each thread
    int alloc[p][r];        // # of resources of each types currently allocated to each thread
    int need[p][r];         // indicates the remaining resource needs of each thread
};

// Calculate need of each Process
void Calc_Need(int max[p][r], int alloc[p][r], int need[p][r])
{
    // Need = Maximum - Allocation
    for(int i=0; i<p; i++)
        for(int j=0; j<r; j++)
            need[i][j] = max[i][j] - alloc[i][j];
}

// Safety Algorithm: checking if system is in a safe state
bool safe(int processes[], int avail[r], int alloc[][r], int max[][r])
{
    // Calculate Need Matrix
    int need[p][r];
    Calc_Need(max, alloc, need);
    
    // Mark all Process as not finished
    bool finish[p] = {0};
    
    // Variable for safe sequence
    int safe_sequence[p];
    
    // Copy of available resources
    int work[r];
    for (int i=0; i<r; i++)
    {work[i] = avail[i];}

    // Process are not Finished
    int count = 0;
    while (count < p)
    {
        // Finding finish(i) = false && Need(i) <= work
        bool found = false;
        for(int pr = 0; pr < p; pr++)
        {
            // finish false?
            if(finish[pr] == 0)
            {
            // check to see if current process resources are less than available resources
                int j;
                for(j = 0; j<r; j++)
                    if(need[pr][j] > work[j])
                        break;
            // if all needs of the process are satisified
                if(j == r)
                {
                    // allocate sources to current process
                    for(int k=0; k<r; k++)
                        work[k] += alloc[p][k];
                    
                    // Add process to the sequence
                    safe_sequence[count++] = pr;
                    
                    // Mark current process as finished
                    finish[pr] = 1;
                    
                    // Exit if statement
                    found = true;
                }
                
            }
        }
        // If we can't find a process to continue in a safe state
        if (found == false)
        {
            cout << "System is not in a safe state\n";
            return false;
        }
    }
    
    cout << "System is in a safe state.\nSequence of Processes is:";
    for(int i=0; i<p; i++)
        cout << safe_sequence[i] << " ";
    
    cout << "\n";
    return true;
}

// Main
int main()
{
    // 5 Processes
    int processes[] = {0,1,2,3,4};
    
    // Available Resources of each instance
    int avail[] = {4,4,3};
    
    // Maximum Resources (r) that can be allocated to process
    int max[][r] = {{7,5,3}, {3,2,2}, {9,0,2}, {2,2,2}, {4,3,3}};
    
    // Allocated resources to process
    int alloc[][r] = {{0,1,0}, {2,0,0}, {3,0,2}, {2,1,1}, {0,0,2}};
    
    // Safe State
    safe(processes, avail,alloc, max);
    
    return 0;
}
